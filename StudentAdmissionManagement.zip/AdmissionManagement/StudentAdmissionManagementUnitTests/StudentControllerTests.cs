﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Web.Mvc;
using NUnit.Framework;
using StudentAdmissionManagement;
using StudentAdmissionManagement.Controllers;
using StudentAdmissionManagement.Models;
using System.ComponentModel.DataAnnotations;

namespace StudentAdmissionManagementUnitTests
{
    [TestFixture]
    public class StudentControllerTests
    {
        Assembly assembly;
        Type ctrlrClassName, dbEntities, modelClassName, blClassName;
        BLStudents blStudent;

        void ValidateObject<T>(T obj)
        {
            var type = typeof(T);
            var meta = type.GetCustomAttributes(false).OfType<MetadataTypeAttribute>().FirstOrDefault();
            if (meta != null)
            {
                type = meta.MetadataClassType;
            }
            var propertyInfo = type.GetProperties();
            foreach (var info in propertyInfo)
            {
                var attributes = info.GetCustomAttributes(false).OfType<ValidationAttribute>();
                foreach (var attribute in attributes)
                {
                    var objPropInfo = obj.GetType().GetProperty(info.Name);
                    attribute.Validate(objPropInfo.GetValue(obj, null), info.Name);
                }
            }
        }

        [SetUp]
        public void Setup()
        {
            assembly = Assembly.Load("StudentAdmissionManagement");
            ctrlrClassName = assembly.GetType("StudentAdmissionManagement.Controllers.StudentsController");
            modelClassName = assembly.GetType("StudentAdmissionManagement.Student");
            blClassName = assembly.GetType("StudentAdmissionManagement.Models.BLStudents");
            dbEntities = assembly.GetType("StudentAdmissionManagement.StudentAdmissionEntities");
        }

        [TestCase]
        public void StudentsController_WhenNoSuchClassFound_WarnsUser()
        {
            if (ctrlrClassName == null)
                Assert.Fail("No controller class with the name 'StudentsController' is implemented OR Did you change the class name");
        }
        [TestCase]
        public void DBContext_WhenNoSuchClassFound_WarnsUser()
        {
            if (dbEntities == null)
                Assert.Fail("No DBContext class with the name 'StudentAdmissionEntities' is implemented as required OR Did you change the class name");
        }
        [TestCase]
        public void Index_WhenNoSuchActionMethodFound_WarnsUser()
        {
            if (ctrlrClassName != null)
            {
                MethodInfo testMethod = ctrlrClassName.GetMethods().Where(x => x.Name.Equals("Index")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();
                Assert.IsNotNull(testMethod, "Method Index NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'StudentsController' is implemented  as per the requirement OR Did you change the class name");
        }
        [TestCase]
        public void Delete_WhenNoSuchActionMethodFound_WarnsUser()
        {
            if (ctrlrClassName != null)
            {
                MethodInfo testMethod = ctrlrClassName.GetMethods().Where(x => x.Name.Equals("Delete")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();
                Assert.IsNotNull(testMethod, "Method Delete NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'StudentsController' is implemented  as per the requirement OR Did you change the class name");
        }
        [TestCase]
        public void Create_WhenNoSuchActionMethodFound_WarnsUser()
        {
            if (ctrlrClassName != null)
            {
                MethodInfo testMethod = ctrlrClassName.GetMethods().Where(x => x.Name.Equals("Create")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method Create NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'StudentsController' is implemented  as per the requirement OR Did you change the class name");
        }
        [TestCase]
        public void Create_WhenNoSuchPostActionMethodFound_WarnsUser()
        {
            if (ctrlrClassName != null)
            {
                MethodInfo testMethod = ctrlrClassName.GetMethods().Where(x => x.Name.Equals("Create")
                                           && x.GetParameters().Count() == 1
                                           && x.GetParameters().First().ParameterType == typeof(Student)
                                           && x.ReturnType == typeof(ActionResult)
                                           && x.CustomAttributes.First().AttributeType.Name
                                                    .Equals("HttpPostAttribute")).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method Create NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'StudentsController' is implemented  as per the requirement OR Did you change the class name");
        }
        [TestCase]
        public void Edit_WhenNoSuchActionMethodFound_WarnsUser()
        {
            if (ctrlrClassName != null)
            {
                MethodInfo testMethod = ctrlrClassName.GetMethods().Where(x => x.Name.Equals("Edit")
                                           && x.GetParameters().Count() == 1
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method Edit NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'StudentsController' is implemented  as per the requirement OR Did you change the class name");
        }
        [TestCase]
        public void Edit_WhenNoSuchPostActionMethodFound_WarnsUser()
        {
            if (ctrlrClassName != null)
            {
                MethodInfo testMethod = ctrlrClassName.GetMethods().Where(x => x.Name.Equals("Edit")
                                           && x.GetParameters().Count() == 1
                                           && x.GetParameters().First().ParameterType == typeof(Student)
                                           && x.ReturnType == typeof(ActionResult)
                                           && x.CustomAttributes.First().AttributeType.Name
                                                    .Equals("HttpPostAttribute")).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method Create NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'StudentsController' is implemented  as per the requirement OR Did you change the class name");
        }
        [TestCase]
        public void DbEntities_InitalizesDbContext()
        {
            try
            {
                using (StudentAdmissionEntities ctx = new StudentAdmissionEntities())
                {
                    if (modelClassName != null)
                    {
                        ConstructorInfo classConstructor = modelClassName.GetConstructor(Type.EmptyTypes);
                        object classObject = classConstructor.Invoke(new object[] { });

                        Assert.IsNotNull(ctx);
                    }
                    else
                        Assert.Fail("No class with the name 'StudentAdmissionEntities' is implemented OR Did you change the class name");
                }
            }
            catch (Exception)
            {
                Assert.Fail("Operating Student details from the database failed. Exception should not be thrown. Please provide all mandatory fields valid data and check the destination action name.");
            }
        }
        [TestCase]
        public void BLEntities_InitalizeBusinessModel()
        {
            try
            {
                blStudent = new BLStudents();
                if (ctrlrClassName != null)
                {
                    ConstructorInfo classConstructor = ctrlrClassName.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    Assert.IsNotNull(blStudent);
                }
                else
                    Assert.Fail("No class with the name 'BLStudents' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Operating Student details from the database failed. Exception should not be thrown. Please provide all mandatory fields valid data and check the destination action name.");
            }
        }
        [Test]
        public void Student_Should_Not_Be_Valid_When_Some_Properties_Incorrect()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            var studentsController = new StudentsController();
            using (StudentAdmissionEntities db = new StudentAdmissionEntities())
            {
                Student student = new Student()
                {
                    stuName = null,
                    stuAge = 0,
                    stuGender = null,
                    stuDOB = DateTime.MinValue,
                    stuStatus = 0,
                    stuCourseId = 0
                };
                ValidateObject(student);

                //Initialize ModelState 
                var modelBinder = new ModelBindingContext()
                {
                    ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                      () => student, student.GetType()),
                    ValueProvider = new NameValueCollectionValueProvider(
                                        new NameValueCollection(), CultureInfo.InvariantCulture)
                };
                var binder = new DefaultModelBinder().BindModel(
                                 new ControllerContext(), modelBinder);

                try
                {
                    if (blClassName != null)
                    {
                        MethodInfo[] testMethods = blClassName.GetMethods(allBindings);
                        MethodInfo testMethod = default;

                        foreach (var item in testMethods)
                        {
                            if (item.CustomAttributes.Count() > 0)
                            {
                                if (item.IsGenericMethod == false && item.Name.Equals("AddOrUpdateStudent")
                                    && item.GetParameters().Count() == 1
                                    && item.GetParameters().First().ParameterType == typeof(Student))
                                {
                                    testMethod = item;
                                    break;
                                }
                            }
                        }

                        Assert.IsNotNull(testMethod, "Action 'AddOrUpdateStudent' NOT implemented OR check spelling");
                    }
                    else
                        Assert.Fail("No class with the name 'StudentsController' is implemented OR Did you change the class name");
                }
                catch (Exception)
                {
                    Assert.Fail("Adding/Updating student details to the database failed. verify the state of model object");
                }
            }
        }
        [Test]
        public void IndexAction_When_Invoked_Return_StudentsList(string searchText = null)
        {
            //Arrange 
            using (StudentAdmissionEntities db = new StudentAdmissionEntities())
            {
                try
                {
                    ctrlrClassName = assembly.GetType("StudentAdmissionManagement.Controllers.StudentsController");

                    if (ctrlrClassName != null)
                    {
                        MethodInfo testMethod = ctrlrClassName.GetMethods().Where(x => x.Name.Equals("Index")
                                               && x.GetParameters().Count() == 0
                                               && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                        Assert.IsNotNull(testMethod,
                            "Action 'Index' GET NOT implemented with return type 'ActionResult' OR check spelling");

                        ConstructorInfo classConstructor = ctrlrClassName.GetConstructor(Type.EmptyTypes);
                        object classObject = classConstructor.Invoke(new object[] { });

                        var viewResult = (ViewResult)testMethod.Invoke(classObject, new object[] { });
                        var studentsList = (IEnumerable<Student>)viewResult.ViewData.Model;
                        Assert.AreEqual(db.Students.ToList().Count, studentsList.ToList().Count,
                            "Verify whether you fetched the data from the database correctly or not");


                        studentsList = (from stu in studentsList
                                        join co in db.Courses on stu.stuCourseId equals co.coId
                                        join ss in db.Student_Status on stu.stuStatus equals ss.ssId
                                        where (stu.stuName + co.coName + ss.ssName).ToLower().Contains(searchText.ToLower())
                                        select stu).ToList();

                        var lstfiltered = (from stu in db.Students
                                           join co in db.Courses on stu.stuCourseId equals co.coId
                                           join ss in db.Student_Status on stu.stuStatus equals ss.ssId
                                           where (stu.stuName + co.coName + ss.ssName).ToLower().Contains(searchText.ToLower())
                                           select stu).ToList();

                        Assert.AreEqual(db.Students.ToList().Count, studentsList.ToList().Count,
                            "Verify whether you fetched the data from the database correctly or not");
                    }
                    else
                        Assert.Fail("No class with the name 'StudentsController' is implemented OR Did you change the class name");
                }
                catch (Exception)
                {
                    Assert.Fail("Exception should not be thrown. Please check the application logic");
                }
            }

        }
        [Test]
        public void AddOrUpdateStudent_SavesToDatabase_IDAutoGenerated_ValidModel()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            Student studentObj = new Student()
            {
                stuName = "Ishan Malik",
                stuAge = 30,
                stuGender = "m",
                stuDOB = new DateTime(1989, 12, 9),
                stuStatus = 1,
                stuCourseId = 1,
                stuSuspendTillDate = null
            };
            
            using (StudentAdmissionEntities db = new StudentAdmissionEntities())
            {
                try
                {
                    blClassName = assembly.GetType("StudentAdmissionManagement.Models.BLStudents");

                    if (blClassName != null)
                    {
                        MethodInfo[] testMethods = blClassName.GetMethods(allBindings);
                        MethodInfo testMethod = default;

                        foreach (var item in testMethods)
                        {
                            if (item.CustomAttributes.Count() > 0)
                            {
                                if (item.IsGenericMethod == false && item.Name.Equals("AddOrUpdateStudent")
                                    && item.GetParameters().Count() == 1
                                    && item.GetParameters().First().ParameterType == typeof(Student))
                                {
                                    testMethod = item;
                                    break;
                                }
                            }
                        }

                        Assert.IsNotNull(testMethod, "Action 'AddPassport' NOT implemented OR check spelling");

                        ConstructorInfo classConstructor = blClassName.GetConstructor(Type.EmptyTypes);
                        object classObject = classConstructor.Invoke(new object[] { });

                        //Check if database is having records? Otherwise can't get Max()
                        if (db.Students.Count() == 0)
                        {
                            testMethod.Invoke(classObject, new object[] { studentObj });
                        }

                        //Act 
                        int maxIdBefore = db.Students.Max(i => i.stuId);

                        RedirectToRouteResult result = (RedirectToRouteResult)testMethod.Invoke(classObject, new object[] { studentObj });
                        int maxIdAfter = db.Students.Max(i => i.stuId);

                        //Assert                     
                        Assert.That(maxIdBefore + 1 == maxIdAfter, "StudentID should be Auto Generated.");
                    }
                    else
                        Assert.Fail("No class with the name 'StudentsController' is implemented OR Did you change the class name");
                }
                catch (Exception)
                {
                    Assert.Fail("Adding/Updating student details to the database failed. Exception should not be thrown. Please provide all mandatory fields valid data and check the destination action name.");
                }
            }

        }

    }
}
