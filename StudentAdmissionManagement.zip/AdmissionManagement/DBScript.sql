﻿USE [StudentAdmission]
GO

CREATE TABLE [dbo].[Course_Status] (
    [csId]   INT           IDENTITY (1, 1) NOT NULL,
    [csName] NVARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([csId] ASC)
);

CREATE TABLE [dbo].[Courses] (
    [coId]       INT           IDENTITY (1, 1) NOT NULL,
    [coName]     NVARCHAR (50) NOT NULL,
    [coNoOfSems] SMALLINT      NOT NULL,
    [coStatus]   INT           NOT NULL,
    PRIMARY KEY CLUSTERED ([coId] ASC),
    CONSTRAINT [FK_Courses_ToTable] FOREIGN KEY ([coStatus]) REFERENCES [dbo].[Course_Status] ([csId])
);

CREATE TABLE [dbo].[Student_Status] (
    [ssId]   INT           IDENTITY (1, 1) NOT NULL,
    [ssName] NVARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([ssId] ASC)
);

CREATE TABLE [dbo].[Students] (
    [stuId]              INT           IDENTITY (1, 1) NOT NULL,
    [stuName]            NVARCHAR (50) NOT NULL,
    [stuAge]             SMALLINT      NOT NULL,
    [stuGender]          CHAR (1)      DEFAULT ('m') NOT NULL,
    [stuDOB]             DATETIME      NOT NULL,
    [stuStatus]          INT           NOT NULL,
    [stuCourseId]        INT           NOT NULL,
    [stuSuspendTillDate] DATETIME      NULL,
    PRIMARY KEY CLUSTERED ([stuId] ASC),
    CONSTRAINT [FK_Students_Courses] FOREIGN KEY ([stuCourseId]) REFERENCES [dbo].[Courses] ([coId]),
    CONSTRAINT [FK_Students_Student_Status] FOREIGN KEY ([stuStatus]) REFERENCES [dbo].[Student_Status] ([ssId])
);

