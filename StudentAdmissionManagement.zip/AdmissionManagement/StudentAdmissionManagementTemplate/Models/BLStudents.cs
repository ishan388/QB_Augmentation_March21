﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StudentAdmissionManagementTemplate.Models
{
    public class BLStudents
    {
        public short CalculateAge(DateTime dob)
        {
            return Convert.ToInt16(((DateTime.Now - dob).Days) / 365);
        }

        public void AddOrUpdateStudent(Student student)
        {

            // Code Here

        }

        public List<Student> GetStudentsList()
        {
            List<Student> lstStudent = new List<Student>();

            // Code Here

            return lstStudent;
        }

        public List<Student> GetStudentsList(string searchText)
        {
            List<Student> lstStudent = new List<Student>();

            // Code Here

            return lstStudent;
        }

        public Student GetStudentDetails(int studentId)
        {
            Student student = new Student();

            // Code Here

            return student;
        }

        public void RemoveStudent(int studentId)
        {
            // Code Here

        }

        public List<Student_Status> GetStudentStatusList()
        {
            List<Student_Status> lstStudentStatus = new List<Student_Status>();

            // Code Here

            return lstStudentStatus;
        }

        
    }
}