﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StudentAdmissionManagementTemplate.Models
{
    public class BLCourses
    {
        public void AddOrUpdateCourse(Course course)
        {
            // Code Here

        }

        public List<Course> GetCoursesList()
        {
            List<Course> lstCourse = new List<Course>();

            // Code Here

            return lstCourse;
        }

        public Course GetCourseDetails(int courseId)
        {
            Course course = new Course();
            
            // Code Here

            return course;
        }

        public void RemoveCourse(int courseId)
        {
            // Code Here

        }

        public List<Course_Status> GetCourseStatusList()
        {
            List<Course_Status> lstStatus = new List<Course_Status>();
            
            // Code Here
            
            return lstStatus;
        }
    }
}